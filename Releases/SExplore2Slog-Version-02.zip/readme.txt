$Id: readme.txt 405fe2807fa2 2012/01/22 18:22:55 Bernhard $

Installation:
=============

1. copy conf.inc.php_example to conf.inc.php

2. adapt the file according to your needs

3. install to your webserver


Change History
==============

Version-0-4: 2012-02-25

 * bugfixes in multi-inverte support

Version-03: 31.01.2012
 
 * also put Pmax to days.js and days_hist.js
 * create min_cur.js
 * improved handling of timezone

Version-02: 23.01.2012

 * now also create minYYMMDD.js
 * now support two inverters
 * Now creates all SolarLog files
 * bugfixes

Version-01: 10.01.2012

 * initial version

 