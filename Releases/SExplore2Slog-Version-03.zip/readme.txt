$Id: readme.txt 405fe2807fa2 2012/01/22 18:22:55 Bernhard $

Installation:

1. copy conf.inc.php_example to conf.inc.php

2. adapt the file according to your needs

3. install to your webserver
