<?php
system('zip -r -p Deploy/SExplore2Slog.zip *.php Classes')
?>